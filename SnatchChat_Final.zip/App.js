
// Snatch Chat — React + Tailwind Site with Age Gate, Spinner, Model Dashboard, and Earnings Management

import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";

function Home() {
  return (
    <div className="p-10 text-center">
      <h1 className="text-5xl font-bold text-pink-600 mb-2">Welcome to Snatch💋Chat</h1>
      <p className="text-md italic text-gray-600 animate-pulse mb-4">“We’ll do everything your lady won’t do.”</p>
      <p className="text-xl italic text-gray-700 mb-6 animate-pulse">“We’ll do everything your lady won’t do.”</p>
      <p className="text-lg text-gray-700 mb-6">Voice connections where desire meets discretion.</p>
      <div className="flex justify-center gap-4">
        <Link to="/models">
          <button className="bg-pink-500 hover:bg-pink-600 text-white px-6 py-3 rounded-xl">Browse Models</button>
        </Link>
        <p className="text-sm text-gray-600 mt-4">Clients can create a pro name — or choose to remain anonymous.</p>
        <Link to="/signup">
          <button className="bg-gray-100 border-4 border-neon-pink border-pink-500 text-pink-600 px-6 py-3 rounded-xl hover:bg-pink-50">Join Now</button>
        </Link>
      </div>
    </div>
  );
}
